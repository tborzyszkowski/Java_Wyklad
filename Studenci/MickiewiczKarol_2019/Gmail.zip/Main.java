public class Main {

    public static void main(String[] args) {

        Punkt punkt = new Punkt(2.0, 5.0);
        punkt.shift(2.0, 5.0);
        System.out.println(punkt.getX());
        System.out.println(punkt.getY());


        Punkt punkt1 = new Punkt();
        System.out.println(punkt1.distance(new Punkt(2.0, 5.0)));

        Punkt punktOdcinka1 = new Punkt(1, 3);
        Punkt punktOdcinka2 = new Punkt(-1, 5);
        Odcinek odcinek = new Odcinek(punktOdcinka1, punktOdcinka2);
        Punkt punktProstopadly = new Punkt(0, 5);
        System.out.println(odcinek.distance(punktProstopadly));

    }

}
